import React from 'react';

const RequestCard: React.FC<{ title: string; detail: string; value: string; hoverText: string }> = ({ title, detail, value, hoverText }) => (
    <div className="bg-white rounded-lg p-6 text-center transition-all duration-300 ease-in-out hover:shadow-xl hover:scale-105 flex-1 border-b-4 border-transparent hover:border-cyan-600 group relative">
        <h3 className="text-lg font-semibold text-slate-600">{title}</h3>
        <p className="text-4xl font-bold text-cyan-700 my-2">{value}</p>
        <p className="text-slate-800">{detail}</p>
        <div className="absolute -top-2 left-1/2 -translate-x-1/2 w-max max-w-xs
                        mt-[-2.5rem] px-3 py-1.5 bg-slate-800 text-white text-sm rounded-md 
                        opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none
                        shadow-lg
                        after:content-[''] after:absolute after:left-1/2 after:top-[100%] 
                        after:-translate-x-1/2 after:border-8 after:border-x-transparent 
                        after:border-b-transparent after:border-t-slate-800">
            {hoverText}
        </div>
    </div>
);

const RequestSection: React.FC = () => {
  return (
    <div className="flex flex-col md:flex-row gap-6">
        <RequestCard 
            title="Pay Hike"
            value="50%"
            detail="Requesting an increase in compensation."
            hoverText="Based on expanded leadership, proven impact, and market value."
        />
        <RequestCard
            title="Promotion"
            value="Assistant Manager"
            detail="Operations"
            hoverText="Ready to step into a formal management role, leveraging my operational leadership to drive broader strategic initiatives."
        />
    </div>
  );
};

export default RequestSection;