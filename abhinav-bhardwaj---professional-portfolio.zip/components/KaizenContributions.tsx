import React from 'react';
import { CogIcon, UsersIcon } from './icons';

const kaizenData = [
  { area: 'Process', problem: 'Inconsistent follow-ups', improvement: 'Automated WhatsApp + email sequences', result: 'Improved student engagement' },
  { area: 'Team', problem: 'Tool unfamiliarity', improvement: 'Walkthroughs + live tool training', result: 'Reduced dependency + faster resolution' },
  { area: 'Process', problem: 'SEVIS status manual tracking', improvement: 'Centralized SEVIS dashboard', result: 'Reduced manual errors & time' },
  { area: 'Team', problem: 'Frequent email/PDF errors', improvement: 'Created a POC mail book', result: 'Better accuracy, less rework' },
];

const KaizenContributions: React.FC = () => {
  return (
    <div className="bg-white/80 backdrop-blur-sm rounded-xl shadow-lg overflow-hidden">
      <div className="overflow-x-auto">
        <table className="w-full text-left table-auto">
          <thead className="bg-slate-100/80 border-b-2 border-slate-200">
            <tr>
              <th className="p-4 text-sm font-semibold text-slate-700 uppercase tracking-wider">Area</th>
              <th className="p-4 text-sm font-semibold text-slate-700 uppercase tracking-wider">Problem Identified</th>
              <th className="p-4 text-sm font-semibold text-slate-700 uppercase tracking-wider">Improvement Made</th>
              <th className="p-4 text-sm font-semibold text-slate-700 uppercase tracking-wider">Result</th>
            </tr>
          </thead>
          <tbody>
            {kaizenData.map((item, index) => (
              <tr 
                key={index} 
                className="border-b border-slate-200/80 last:border-b-0
                           group transition-all duration-300 ease-in-out hover:bg-cyan-50/50 hover:shadow-md hover:scale-[1.01]"
                style={{ animation: `fade-in-up 0.6s ${index * 0.15}s ease-out forwards`, opacity: 0 }}
              >
                <td className="p-4 align-middle">
                  <div className="flex items-center font-semibold text-cyan-800">
                    {item.area === 'Process' 
                      ? <CogIcon className="w-5 h-5 mr-3 text-cyan-700 flex-shrink-0" /> 
                      : <UsersIcon className="w-5 h-5 mr-3 text-cyan-700 flex-shrink-0" />}
                    <span>{item.area}</span>
                  </div>
                </td>
                <td className="p-4 text-slate-600 align-middle">{item.problem}</td>
                <td className="p-4 text-slate-600 align-middle">{item.improvement}</td>
                <td className="p-4 font-medium text-slate-800 align-middle">{item.result}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default KaizenContributions;