import React, { useState, useRef, useEffect } from 'react';
import { GoogleGenAI, GenerateContentResponse } from '@google/genai';
import { CloseIcon, SendIcon, ChatbotIcon } from './icons';

interface Message {
  sender: 'user' | 'bot' | 'loading';
  text: string;
}

const portfolioContext = `
You are an expert AI assistant for Abhinav Bhardwaj's professional portfolio. Your goal is to answer questions based on the following information. Be friendly, professional, and concise.

**Portfolio Overview:**
- Name: Abhinav Bhardwaj
- Current Role: Team Lead, Operations
- Team: SLU Operations
- Joined: August 16, 2022

**Career Timeline:**
- Feb 2025 – Present: Team Lead, Operations (Leading the entire operations team, overseeing all operational workflows, setting performance targets, and driving process improvements across the funnel.)
- May 2024 – Feb 2025: Team Lead, Support (Led the support division, focusing on enhancing student query resolution, improving team response times, and mentoring support specialists.)
- Nov 2023 – May 2024: Assistant Team Lead (Supported Team Lead, mentored juniors, and handled escalations.)
- Jun 2023 – Nov 2023: University Operation Specialist (Managed key operational tasks, streamlined processes, and ensured data integrity.)
- Aug 2022 – May 2023: Student Success Advisor (Guided students, provided support, and ensured retention.)

**Promotions:**
- A clear progression from Student Success Advisor → University Operation Specialist → Assistant Team Lead → Team Lead, Operations.

**Key Contributions & Impact:**
- Leads the entire SLU operations team, driving efficiency and achieving KPIs.
- Manages the funnel database, providing key analytics for strategic decision-making.
- Built Post I-20 Lookup Dashboard for streamlined tracking.
- Corrected Tableau Dashboard for accurate I-20 reporting.
- Reduced Application TAT from 21% to 65%.
- Launched WhatsApp automation, increasing engagement by 25%.
- Improved I-20/visa stage tracking for 15% faster decisions.
- Created SLU training modules for faster onboarding.

**Upcoming Goals:**
- Explore AI agents for chatbots.
- Find more automation opportunities in funnel tracking.
- Lead task & agency management.
- Launch a post-visa & arrival feedback loop.
- Expand the student ambassador network.

**My Spark (What drives me):**
- Energized by: Turning data into insights.
- Connected to org by: Flat hierarchy, open culture.
- Wants to do more of: Funnel strategy, AI innovations, team mentoring.

**Request:**
- Seeking a 50% pay hike and a promotion to Assistant Manager, Operations.
`;

const Chatbot: React.FC<{ isOpen: boolean; onClose: () => void }> = ({ isOpen, onClose }) => {
    const [messages, setMessages] = useState<Message[]>([
        { sender: 'bot', text: "Hello! I'm Abhinav's AI assistant. Ask me anything about his portfolio." }
    ]);
    const [input, setInput] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const messagesEndRef = useRef<HTMLDivElement>(null);

    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    };

    useEffect(scrollToBottom, [messages]);
    
    useEffect(() => {
        if (isOpen) {
             document.body.style.overflow = 'hidden';
        } else {
             document.body.style.overflow = 'auto';
        }
        return () => { document.body.style.overflow = 'auto'; };
    }, [isOpen]);

    const handleSend = async () => {
        if (!input.trim() || isLoading) return;

        const userMessage: Message = { sender: 'user', text: input };
        setMessages(prev => [...prev, userMessage, { sender: 'loading', text: '...' }]);
        setInput('');
        setIsLoading(true);

        try {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });
            const response: GenerateContentResponse = await ai.models.generateContent({
                model: 'gemini-2.5-flash-preview-04-17',
                contents: `${portfolioContext}\n\nUser question: "${input}"`,
            });
            
            const botMessage: Message = { sender: 'bot', text: response.text };

            setMessages(prev => [...prev.filter(m => m.sender !== 'loading'), botMessage]);
        } catch (error) {
            console.error("Gemini API error:", error);
            const errorMessage: Message = { sender: 'bot', text: "Sorry, I'm having a little trouble connecting right now. Please try again later." };
            setMessages(prev => [...prev.filter(m => m.sender !== 'loading'), errorMessage]);
        } finally {
            setIsLoading(false);
        }
    };
    
    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black/60 z-50 flex justify-center items-center p-4" onClick={onClose}>
            <div className="bg-slate-100 rounded-2xl shadow-2xl w-full max-w-lg h-[80vh] flex flex-col transform transition-all animate-fade-in-up" onClick={e => e.stopPropagation()}>
                <header className="flex items-center justify-between p-4 border-b border-slate-300 bg-white rounded-t-2xl">
                    <div className="flex items-center">
                        <div className="bg-cyan-600 text-white p-2 rounded-full mr-3">
                           <ChatbotIcon className="w-6 h-6" />
                        </div>
                        <h2 className="text-xl font-bold text-slate-800">AI Portfolio Assistant</h2>
                    </div>
                    <button onClick={onClose} className="text-slate-500 hover:text-slate-800">
                        <CloseIcon />
                    </button>
                </header>

                <main className="flex-1 p-4 overflow-y-auto space-y-4">
                    {messages.map((msg, index) => (
                        <div key={index} className={`flex items-end gap-2 ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
                           {msg.sender === 'bot' && <div className="w-8 h-8 rounded-full bg-cyan-600 text-white flex items-center justify-center flex-shrink-0"><ChatbotIcon className="w-5 h-5"/></div>}
                            <div className={`max-w-xs md:max-w-md px-4 py-2 rounded-2xl ${
                                msg.sender === 'user' ? 'bg-cyan-700 text-white rounded-br-none' : 'bg-white text-slate-800 rounded-bl-none shadow-sm'
                            }`}>
                                {msg.sender === 'loading' ? (
                                    <div className="flex items-center justify-center gap-1">
                                        <span className="h-2 w-2 bg-slate-400 rounded-full animate-bounce [animation-delay:-0.3s]"></span>
                                        <span className="h-2 w-2 bg-slate-400 rounded-full animate-bounce [animation-delay:-0.15s]"></span>
                                        <span className="h-2 w-2 bg-slate-400 rounded-full animate-bounce"></span>
                                    </div>
                                ) : (
                                    <p className="whitespace-pre-wrap">{msg.text}</p>
                                )}
                            </div>
                        </div>
                    ))}
                    <div ref={messagesEndRef} />
                </main>

                <footer className="p-4 border-t border-slate-300 bg-white rounded-b-2xl">
                    <div className="flex items-center gap-2">
                        <input
                            type="text"
                            value={input}
                            onChange={(e) => setInput(e.target.value)}
                            onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                            placeholder="Ask about my skills, goals..."
                            className="w-full p-3 bg-slate-100 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-500"
                            disabled={isLoading}
                        />
                        <button onClick={handleSend} disabled={isLoading || !input.trim()} className="bg-cyan-600 text-white p-3 rounded-lg disabled:bg-cyan-400 disabled:cursor-not-allowed hover:bg-cyan-700 transition-colors">
                            <SendIcon />
                        </button>
                    </div>
                </footer>
            </div>
        </div>
    );
};

export default Chatbot;