import React from 'react';

interface SectionProps {
  title: string;
  icon: React.ReactNode;
  children: React.ReactNode;
}

const Section: React.FC<SectionProps> = ({ title, icon, children }) => {
  return (
    <section className="bg-slate-800/50 backdrop-blur-sm p-6 md:p-8 rounded-xl shadow-lg border border-slate-700/50 transition-all duration-300 ease-in-out hover:shadow-[0_0_25px_rgba(34,211,238,0.2)] hover:border-cyan-500/50">
      <div className="flex items-center mb-6">
        <div className="text-cyan-400 mr-4">{icon}</div>
        <h2 className="text-2xl md:text-3xl font-bold text-slate-100">{title}</h2>
      </div>
      <div className="text-slate-300">
        {children}
      </div>
    </section>
  );
};

export default Section;