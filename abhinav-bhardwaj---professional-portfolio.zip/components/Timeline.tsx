import React from 'react';

const timelineData = [
  {
    period: 'Aug 2022 – May 2023',
    role: 'Student Success Advisor',
    responsibilities: 'Guided students through their academic journey, providing support and resources to ensure retention and success.',
    color: 'teal',
  },
  {
    period: 'Jun 2023 – Nov 2023',
    role: 'University Operation Specialist',
    responsibilities: 'Managed key operational tasks, streamlined processes, and ensured data integrity for university systems.',
    color: 'cyan',
  },
  {
    period: 'Nov 2023 – May 2024',
    role: 'Assistant Team Lead',
    responsibilities: 'Supported the Team Lead in managing daily operations, mentored junior team members, and handled complex escalations.',
    color: 'sky',
  },
  {
    period: 'May 2024 – Feb 2025',
    role: 'Team Lead, Support',
    responsibilities: 'Led the support division, focusing on enhancing student query resolution, improving team response times, and mentoring support specialists.',
    color: 'blue',
  },
  {
    period: 'Feb 2025 – Present',
    role: 'Team Lead, Operations',
    responsibilities: 'Leading the entire operations team, overseeing all operational workflows, setting performance targets, and driving process improvements across the funnel.',
    color: 'indigo',
  },
];

const TimelineEvent: React.FC<{ data: typeof timelineData[0]; isLast: boolean }> = ({ data, isLast }) => {
  const { period, role, responsibilities, color } = data;
  const borderColor = `border-${color}-600`;
  const bgColor = `bg-${color}-600`;
  const textColor = `text-${color}-700`;

  return (
    <div className="relative pl-8 sm:pl-32 py-6 group">
      {/* Vertical line */}
      {!isLast && <div className="absolute top-0 left-4 h-full w-0.5 bg-slate-300"></div>}
      
      {/* Dot */}
      <div className={`absolute top-8 left-[10px] w-2.5 h-2.5 rounded-full ${bgColor} z-10 ring-8 ring-slate-100 group-hover:ring-white transition-all`}></div>

      {/* Date */}
      <div className="absolute top-6 left-12 sm:left-auto sm:right-full sm:mr-12 text-sm font-semibold text-slate-500 whitespace-nowrap">{period}</div>
      
      {/* Card */}
      <div className={`bg-white p-6 rounded-xl shadow-md border-l-4 ${borderColor} transition-all duration-300 group-hover:shadow-xl group-hover:scale-105`}>
        <h3 className={`text-xl font-bold ${textColor} mb-2`}>{role}</h3>
        <p className="text-slate-600">{responsibilities}</p>
      </div>
    </div>
  );
};

const Timeline: React.FC = () => {
  return (
    <div className="relative">
       {/* Fake classes to make sure tailwind includes them */}
       <div className="hidden border-teal-600 bg-teal-600 text-teal-700 border-cyan-600 bg-cyan-600 text-cyan-700 border-sky-600 bg-sky-600 text-sky-700 border-blue-600 bg-blue-600 text-blue-700 border-indigo-600 bg-indigo-600 text-indigo-700"></div>
      {timelineData.map((item, index) => (
        <TimelineEvent key={index} data={item} isLast={index === timelineData.length - 1} />
      ))}
    </div>
  );
};

export default Timeline;