import React from 'react';

const QuoteCard: React.FC = () => {
  return (
    <blockquote className="bg-slate-800/50 border-l-4 border-cyan-500 p-8 rounded-r-lg">
      <p className="text-2xl md:text-3xl italic font-serif text-white" style={{textShadow: '0 1px 10px rgba(255, 255, 255, 0.3)'}}>
        “Don’t chase tasks — chase impact.”
      </p>
      <footer className="mt-4 text-slate-400">
        This advice has helped realign my goals to focus on value creation, not just activity.
      </footer>
    </blockquote>
  );
};

export default QuoteCard;