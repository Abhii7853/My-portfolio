import React from 'react';

const OverviewItem: React.FC<{ label: string; value: string }> = ({ label, value }) => (
  <div className="flex flex-col">
    <span className="text-sm font-semibold text-slate-500 uppercase tracking-wider">{label}</span>
    <span className="text-lg text-slate-800">{value}</span>
  </div>
);

const OverviewCard: React.FC = () => {
  return (
    <div className="bg-white p-6 md:p-8 rounded-xl shadow-md transition-shadow hover:shadow-lg">
       <h2 className="text-2xl md:text-3xl font-bold text-slate-800 mb-6 flex items-center">
         <span className="text-teal-500 mr-3">🌟</span>
         Portfolio Overview
       </h2>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
        <OverviewItem label="Team" value="SLU" />
        <OverviewItem label="Date of Joining" value="August 16, 2022" />
        <OverviewItem label="Review Period" value="Jan 2024 – Mar 2025" />
      </div>
    </div>
  );
};

export default OverviewCard;