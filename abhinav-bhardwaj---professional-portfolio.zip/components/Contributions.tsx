import React from 'react';
import { ChartBarIcon, SparklesIcon } from './icons';

const achievements = [
  {
    title: 'Comprehensive Team Leadership',
    contribution: 'Assumed full leadership of the Saint Louis University (SLU) operations team, overseeing all workflows, setting performance benchmarks, and fostering a culture of continuous improvement.',
    businessImpact: 'Drove a significant uplift in team efficiency and morale, enhanced inter-departmental collaboration, and ensured consistent achievement of all operational KPIs.'
  },
  {
    title: 'Funnel Database & Analytics Ownership',
    contribution: 'Managed the end-to-end admissions funnel database, ensuring data integrity while developing analytical frameworks that converted raw data into actionable strategic insights.',
    businessImpact: 'Empowered leadership with data-backed recommendations, leading to more targeted outreach, optimized resource allocation, and a marked improvement in funnel conversion rates.'
  },
  {
    title: 'Post I-20 Lookup Dashboard',
    contribution: 'Architected and built a self-service lookup dashboard from scratch with help of excelerate team, allowing team to independently track the students post I-20 status in real-time.',
    businessImpact: 'Reduced inbound student queries regarding I-20 status by over 40%, freeing up significant bandwidth for the admissions team to focus on critical application processing.'
  },
  {
    title: 'Tableau Dashboard Correction',
    contribution: 'Identified and rectified critical data integrity issues within the main Tableau Dashboard designed by ryan, ensuring accurate I-20 reporting across the organization.',
    businessImpact: 'Restored trust in data-driven decision-making and prevented incorrect reporting to stakeholders. This ensured compliance and accurate funnel analysis.'
  },
  {
    title: 'Application TAT Optimization',
    contribution: 'Re-engineered the application processing workflow, identifying bottlenecks and implementing streamlined procedures.',
    businessImpact: 'Increased the percentage of applications processed within the target Turnaround Time (TAT) from a mere 21% to a consistent 65%, enhancing applicant satisfaction.'
  },
  {
    title: 'WhatsApp Automation Initiative',
    contribution: 'Designed and launched an automated WhatsApp communication sequence for proactive student engagement and query resolution.',
    businessImpact: 'Achieved a 25% increase in student engagement metrics and provided instant, 24/7 support for common questions, improving the overall applicant experience.'
  },
  {
    title: 'Enhanced Visa Stage Tracking',
    contribution: 'Developed a more granular and proactive tracking system for the I-20 and visa stages of the student journey.',
    businessImpact: 'Enabled the team to make intervention decisions 15% faster, leading to a higher visa success rate and smoother student onboarding.'
  },
  {
    title: 'SLU Training Modules Creation',
    contribution: 'Created a comprehensive suite of training modules and documentation for new hires specific to Saint Louis University (SLU) processes.',
    businessImpact: 'Reduced new team member onboarding time by 30% and fostered a self-resolving team culture, decreasing dependency on senior staff.'
  },
];

type ContributionItemProps = typeof achievements[0];

const ContributionItem: React.FC<ContributionItemProps> = ({ title, contribution, businessImpact }) => {
  return (
    <div className="group h-80 w-full [perspective:1000px]">
      <div className="relative h-full w-full rounded-xl shadow-lg transition-all duration-700 [transform-style:preserve-3d] group-hover:[transform:rotateY(180deg)]">
        
        {/* Front Face */}
        <div className="absolute inset-0 bg-white rounded-xl border border-slate-200/80 [backface-visibility:hidden]">
          <div className="p-6 h-full flex flex-col justify-between">
            <div>
              <h3 className="text-xl font-bold text-cyan-700 mb-4">{title}</h3>
              <div>
                <div className="flex items-center text-slate-600 font-semibold mb-2">
                  <SparklesIcon className="w-5 h-5 mr-2 text-indigo-500" />
                  My Contribution
                </div>
                <p className="text-slate-700 pl-7 text-sm">{contribution}</p>
              </div>
            </div>
            <div className="text-right text-xs text-slate-400 italic mt-4">
              Hover to reveal impact
            </div>
          </div>
        </div>

        {/* Back Face */}
        <div className="absolute inset-0 bg-sky-50 rounded-xl [transform:rotateY(180deg)] [backface-visibility:hidden]">
           <div className="p-6 h-full flex flex-col">
            <h3 className="text-xl font-bold text-sky-800 mb-4">{title}</h3>
            <div>
              <div className="flex items-center text-sky-800 font-semibold mb-2">
                <ChartBarIcon className="w-5 h-5 mr-2 text-sky-600" />
                Business Impact
              </div>
              <p className="text-sky-900/90 pl-7 font-medium text-sm">{businessImpact}</p>
            </div>
           </div>
        </div>
      </div>
    </div>
  );
};


const Contributions: React.FC = () => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-8">
      {achievements.map((item, index) => (
        <ContributionItem key={index} {...item} />
      ))}
    </div>
  );
};

export default Contributions;