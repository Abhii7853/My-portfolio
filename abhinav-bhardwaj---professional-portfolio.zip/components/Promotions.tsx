import React from 'react';
import { TrendingUpIcon } from './icons';

const PromotionStep: React.FC<{ children: React.ReactNode }> = ({ children }) => (
    <div className="flex items-center p-4 bg-white rounded-lg transition-all hover:shadow-md border border-slate-200/80 group">
        <div className="bg-cyan-100 text-cyan-700 rounded-full p-2.5 mr-4 transition-transform group-hover:scale-110">
            <TrendingUpIcon className="w-5 h-5" />
        </div>
        <div className="text-lg text-slate-700 font-medium">
            {children}
        </div>
    </div>
);

const Promotions: React.FC = () => {
  const progression = [
    'Student Success Advisor → University Operation Specialist → Assistant Team Lead → Team Lead, Operations',
  ];

  return (
    <div className="space-y-4">
       <p className="text-slate-600 mb-4">Demonstrated consistent growth and value, leading to key promotions through the ranks:</p>
      {progression.map((step, index) => (
        <PromotionStep key={index}>
          {step.split('→').map((role, i, arr) => (
            <React.Fragment key={i}>
              <span className={i === 0 ? "text-slate-500" : "text-slate-800 font-semibold"}>{role.trim()}</span>
              {i < arr.length - 1 && <span className="mx-2 text-cyan-500 font-bold">→</span>}
            </React.Fragment>
          ))}
        </PromotionStep>
      ))}
    </div>
  );
};

export default Promotions;