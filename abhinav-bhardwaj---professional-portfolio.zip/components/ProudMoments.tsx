import React from 'react';
import TrophyIcon from './icons/TrophyIcon';

const momentsData = [
  {
    title: 'Dual Promotions',
    description: 'Achieving back-to-back promotions to Assistant Team Lead and then Team Lead was a validation of my leadership potential and consistent high performance.',
  },
  {
    title: 'Domain Ownership',
    description: 'Being entrusted with full ownership of the support domain was a major step, showing the leadership\'s confidence in my ability to manage critical functions independently.',
  },
  {
    title: 'Leading SLU Operations',
    description: 'Having the opportunity to lead the entire SLU Operations Department was a pinnacle moment, allowing me to shape strategy and guide the team\'s success.',
  },
  {
    title: 'Public Speaking at SLU Start',
    description: 'Speaking at the SLU Start event in Bangalore was a fantastic opportunity to represent the team, share our successes, and connect with a wider audience.',
  },
  {
    title: 'Leadership Recognition',
    description: 'Receiving personal appreciation emails from senior leaders like Robert Reddy and Parul was incredibly motivating and affirmed the impact of my work.',
  },
  {
    title: 'Building from Scratch',
    description: 'Creating and managing the entire SLU team database from the ground up provided a foundational asset for the team and showcased my technical and organizational skills.',
  },
  {
    title: 'Defining Performance',
    description: 'Contributing to the definition of SLU\'s performance goals allowed me to have a direct impact on how success is measured and motivated across the team.',
  },
  {
    title: 'Official Slate Certification',
    description: 'Becoming certified in Slate CRM formalized my expertise in a critical university tool, enhancing my ability to drive process improvements and support my team.',
  },
   {
    title: 'First Promotion',
    description: 'The promotion to University Operations Specialist marked the first major recognition of my contributions and my potential to take on greater operational responsibilities.',
  },
];


const MomentCard: React.FC<{ title: string; description: string }> = ({ title, description }) => {
  return (
    <div className="group h-48 [perspective:1000px]">
      <div className="relative h-full w-full rounded-xl shadow-lg transition-all duration-700 [transform-style:preserve-3d] group-hover:[transform:rotateY(180deg)]">
        
        {/* Front Face */}
        <div className="absolute inset-0 bg-gradient-to-br from-slate-700 to-slate-800 rounded-xl border border-slate-600 [backface-visibility:hidden] flex flex-col justify-center items-center text-center p-4">
          <TrophyIcon className="w-10 h-10 text-amber-400 mb-3" />
          <h3 className="text-md font-bold text-slate-100">{title}</h3>
          <p className="text-xs text-slate-400 mt-2 italic">Hover to learn more</p>
        </div>

        {/* Back Face */}
        <div className="absolute inset-0 bg-gradient-to-br from-amber-200 to-yellow-300 rounded-xl [transform:rotateY(180deg)] [backface-visibility:hidden] p-4 flex items-center justify-center">
            <p className="text-amber-900 font-medium text-sm text-center">{description}</p>
        </div>
      </div>
    </div>
  );
};


const ProudMoments: React.FC = () => {
  return (
    <div>
      <p className="text-center text-slate-400 mb-8 max-w-2xl mx-auto">
        Beyond titles and tasks, these are the milestones that have truly defined my professional journey and fueled my drive for excellence.
      </p>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
        {momentsData.map((moment, index) => (
          <MomentCard key={index} title={moment.title} description={moment.description} />
        ))}
      </div>
    </div>
  );
};

export default ProudMoments;