import React from 'react';
import TargetIcon from './icons/TargetIcon';

const goals = [
  {
    title: 'Pioneer with AI',
    description: 'Explore and implement AI-driven agents for proactive, intelligent chatbot communication to enhance user engagement.',
  },
  {
    title: 'Automate for Insight',
    description: 'Deepen automation within the admissions funnel to unlock new efficiencies and gain sharper, data-backed tracking insights.',
  },
  {
    title: 'Lead with Ownership',
    description: 'Take full ownership of task and funnel management, driving projects to completion and ensuring stakeholder alignment.',
  },
  {
    title: 'Close the Loop',
    description: 'Launch a comprehensive feedback system for post-visa and arrival stages to continuously refine the student experience.',
  },
  {
    title: 'Grow the Community',
    description: 'Strategically expand and empower the student ambassador network to foster a stronger, more engaged community.',
  },
];

const GoalItem: React.FC<{ title: string; description: string }> = ({ title, description }) => (
    <div className="relative group p-6 rounded-lg bg-slate-800/50 border border-slate-700/50 overflow-hidden h-full
                    transition-all duration-300 hover:border-cyan-400/80 hover:scale-105">
      <div className="absolute -inset-2 bg-gradient-to-r from-cyan-500/50 via-sky-500/50 to-indigo-500/50 
                     blur-xl opacity-0 group-hover:opacity-20 transition-opacity duration-500 animate-aurora bg-[length:300%_300%]"></div>
      <div className="relative">
        <div className="flex items-center mb-3">
            <div className="text-cyan-400 mr-3">
                <TargetIcon className="w-5 h-5"/>
            </div>
            <h3 className="text-lg font-bold text-slate-100">{title}</h3>
        </div>
        <p className="text-slate-300 text-sm">{description}</p>
      </div>
    </div>
);

const Goals: React.FC = () => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {goals.map((goal, index) => (
        <GoalItem key={index} title={goal.title} description={goal.description} />
      ))}
    </div>
  );
};

export default Goals;