import React from 'react';
import { SparklesIcon, TrendingUpIcon, LinkIcon } from './icons';

interface SparkCardProps {
  icon: React.ReactNode;
  title: string;
  children: React.ReactNode;
  gradient: string;
}

const SparkCard: React.FC<SparkCardProps> = ({ icon, title, children, gradient }) => (
  <div className={`relative p-6 rounded-lg overflow-hidden h-full flex flex-col transition-transform duration-300 hover:scale-105`}>
    <div className={`absolute inset-0 ${gradient} opacity-25`}></div>
    <div className="relative z-10 flex-grow">
      <div className="flex items-center mb-4">
        <div className="mr-3">{icon}</div>
        <h3 className="font-bold text-lg text-white">{title}</h3>
      </div>
      <p className="text-slate-200">{children}</p>
    </div>
  </div>
);

const MySpark: React.FC = () => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      <SparkCard 
        icon={<SparklesIcon className="w-7 h-7 text-purple-300" />}
        title="My Energy"
        gradient="bg-gradient-to-br from-purple-500 to-indigo-600"
      >
        Turning raw data into actionable insights for smarter, more impactful decisions.
      </SparkCard>
      
      <SparkCard 
        icon={<LinkIcon className="w-7 h-7 text-sky-300" />}
        title="My Connection"
        gradient="bg-gradient-to-br from-sky-500 to-cyan-600"
      >
        The flat hierarchy, open culture, and sense of equality that empowers everyone.
      </SparkCard>
      
      <SparkCard 
        icon={<TrendingUpIcon className="w-7 h-7 text-emerald-300" />}
        title="My Ambition"
        gradient="bg-gradient-to-br from-emerald-500 to-green-600"
      >
        To drive funnel strategy, innovate with AI, and mentor the next wave of talent.
      </SparkCard>
    </div>
  );
};

export default MySpark;