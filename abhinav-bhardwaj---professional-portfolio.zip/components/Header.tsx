import React from 'react';
import './Header.css';

const Header: React.FC = () => {
  return (
    <header className="bg-slate-900 text-white p-8 md:p-12 text-center rounded-b-3xl shadow-2xl relative overflow-hidden h-64 flex flex-col items-center justify-center">
        <div id="stars"></div>
        <div id="stars2"></div>
        <div id="stars3"></div>
        <div className="max-w-4xl mx-auto relative z-10">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-extrabold tracking-tight animate-fade-in-up" style={{ textShadow: '0 0 15px rgba(255, 255, 255, 0.4), 0 0 30px rgba(34, 211, 238, 0.2)' }}>
                Abhinav Bhardwaj
            </h1>
            <p className="mt-4 text-xl md:text-2xl text-slate-300 animate-fade-in-up [animation-delay:0.2s]">
                Team Lead, Operations
            </p>
        </div>
    </header>
  );
};

export default Header;