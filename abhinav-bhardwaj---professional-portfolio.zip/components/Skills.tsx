import React from 'react';
import { CheckCircleIcon } from './icons';

const skills = [
  'Team Leadership & Mentoring',
  'Data Analysis & Reporting',
  'Process Automation',
  'Slate CRM',
  'Tableau Dashboards',
  'Student Engagement Strategy',
  'Cross-functional Collaboration',
  'Problem Solving',
];

const SkillBadge: React.FC<{ children: React.ReactNode }> = ({ children }) => (
    <div className="flex items-center bg-cyan-100 text-cyan-900 text-sm font-medium px-4 py-2 rounded-full transform transition-transform hover:scale-105">
        <CheckCircleIcon className="w-5 h-5 mr-2 text-cyan-700" />
        {children}
    </div>
);

const Skills: React.FC = () => {
  return (
    <div className="flex flex-wrap gap-3">
      {skills.map((skill, index) => (
        <SkillBadge key={index}>{skill}</SkillBadge>
      ))}
    </div>
  );
};

export default Skills;