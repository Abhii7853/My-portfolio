import React from 'react';

const QuoteIcon: React.FC<{ className?: string }> = ({ className = 'w-8 h-8' }) => (
  <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="currentColor" viewBox="0 0 24 24">
    <path d="M14.017 21v-7.391c0-5.704 3.731-9.57 8.983-10.609l.995 2.151c-2.432.917-3.495 3.636-3.495 5.849h4.517v10h-11zm-14 0v-7.391c0-5.704 3.748-9.57 8.999-10.609l.996 2.151c-2.433.917-3.495 3.636-3.495 5.849h4.5v10h-11z" />
  </svg>
);

export default QuoteIcon;
