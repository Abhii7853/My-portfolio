import React, { useState, useEffect } from 'react';
import Header from './components/Header';
import OverviewCard from './components/OverviewCard';
import Timeline from './components/Timeline';
import Promotions from './components/Promotions';
import Contributions from './components/Contributions';
import Goals from './components/Goals';
import KaizenContributions from './components/KaizenContributions';
import ProudMoments from './components/ProudMoments';
import MySpark from './components/MySpark';
import QuoteCard from './components/QuoteCard';
import RequestSection from './components/RequestSection';
import Skills from './components/Skills';
import Chatbot from './components/Chatbot';
import AnimatedSection from './components/AnimatedSection';

import { 
  BriefcaseIcon, RocketIcon, TrophyIcon, ChartBarIcon, 
  TargetIcon, LightBulbIcon, SparklesIcon, QuoteIcon, 
  ChevronUpIcon, StarIcon, ChatbotIcon
} from './components/icons';
import Section from './components/Section';


const App: React.FC = () => {
  const [isChatOpen, setChatOpen] = useState(false);
  const [showScrollTop, setShowScrollTop] = useState(false);

  useEffect(() => {
    const checkScrollTop = () => {
      if (!showScrollTop && window.pageYOffset > 400) {
        setShowScrollTop(true);
      } else if (showScrollTop && window.pageYOffset <= 400) {
        setShowScrollTop(false);
      }
    };
    window.addEventListener('scroll', checkScrollTop);
    return () => window.removeEventListener('scroll', checkScrollTop);
  }, [showScrollTop]);

  const scrollTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };


  return (
    <div className="min-h-screen font-sans antialiased">
      <Header />
      <main className="container mx-auto p-4 md:p-8 max-w-5xl">
        <div className="space-y-16">
          <AnimatedSection><OverviewCard /></AnimatedSection>
          
          <AnimatedSection>
            <Section title="Career Timeline" icon={<BriefcaseIcon />}>
              <Timeline />
            </Section>
          </AnimatedSection>

          <AnimatedSection>
            <Section title="Promotions" icon={<RocketIcon />}>
              <Promotions />
            </Section>
          </AnimatedSection>
          
          <AnimatedSection>
            <Section title="Core Competencies" icon={<StarIcon />}>
              <Skills />
            </Section>
          </AnimatedSection>

          <AnimatedSection>
            <Section title="Contributions & Business Impact" icon={<ChartBarIcon />}>
              <Contributions />
            </Section>
          </AnimatedSection>

          <AnimatedSection>
            <Section title="Upcoming Goals" icon={<TargetIcon />}>
              <Goals />
            </Section>
          </AnimatedSection>

          <AnimatedSection>
            <Section title="Kaizen Contributions" icon={<LightBulbIcon />}>
              <KaizenContributions />
            </Section>
          </AnimatedSection>

          <AnimatedSection>
            <Section title="Proud Moments" icon={<TrophyIcon />}>
              <ProudMoments />
            </Section>
          </AnimatedSection>

          <AnimatedSection>
            <Section title="My Spark at Work" icon={<SparklesIcon />}>
              <MySpark />
            </Section>
          </AnimatedSection>

          <AnimatedSection>
            <Section title="Favourite Advice That Shaped My Growth" icon={<QuoteIcon />}>
              <QuoteCard />
            </Section>
          </AnimatedSection>

          <AnimatedSection>
            <Section title="Request" icon={<ChevronUpIcon />}>
              <RequestSection />
            </Section>
          </AnimatedSection>
        </div>
      </main>

       {/* Chatbot FAB */}
      <button
        onClick={() => setChatOpen(true)}
        className="fixed bottom-8 right-8 bg-cyan-600 text-white p-4 rounded-full shadow-lg hover:bg-cyan-700 focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:ring-opacity-50 transition-transform transform hover:scale-110 z-40"
        aria-label="Open AI Assistant"
      >
        <ChatbotIcon />
      </button>

      {/* Scroll to Top Button */}
      {showScrollTop && (
        <button
          onClick={scrollTop}
          className="fixed bottom-24 right-8 bg-slate-700 text-white p-3 rounded-full shadow-lg hover:bg-slate-800 focus:outline-none focus:ring-2 focus:ring-slate-500 focus:ring-opacity-50 transition-opacity z-40"
          aria-label="Scroll to top"
        >
          <ChevronUpIcon className="w-6 h-6"/>
        </button>
      )}

      <Chatbot isOpen={isChatOpen} onClose={() => setChatOpen(false)} />
      
      <footer className="text-center py-8 px-4 text-slate-500 bg-black/20 mt-16">
        <p>This portfolio was enhanced with AI to be more interactive.</p>
        <p>&copy; {new Date().getFullYear()} Abhinav Bhardwaj</p>
      </footer>
    </div>
  );
};

export default App;